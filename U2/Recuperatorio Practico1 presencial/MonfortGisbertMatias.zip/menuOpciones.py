def menu():
    print('\n--- MENU DE OPCIONES ---')
    print('1)_ Mostrar informacion de un nacimiento dado dni mama.')
    print('2)_ Mostrar datos de mamas con partos multiples.')
    opcion = int(input('* Seleccione una opcion 1-2 (0 para terminar): '))
    return opcion
